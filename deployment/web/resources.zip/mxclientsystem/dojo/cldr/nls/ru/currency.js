/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ru/currency",{HKD_displayName:"\u0413\u043e\u043d\u043a\u043e\u043d\u0433\u0441\u043a\u0438\u0439 \u0434\u043e\u043b\u043b\u0430\u0440",CHF_displayName:"\u0428\u0432\u0435\u0439\u0446\u0430\u0440\u0441\u043a\u0438\u0439 \u0444\u0440\u0430\u043d\u043a",JPY_symbol:"\u00a5",CAD_displayName:"\u041a\u0430\u043d\u0430\u0434\u0441\u043a\u0438\u0439 \u0434\u043e\u043b\u043b\u0430\u0440",HKD_symbol:"HK$",CNY_displayName:"\u042e\u0430\u043d\u044c \u0420\u0435\u043d\u043c\u0438\u043d\u0431\u0438",
USD_symbol:"$",AUD_displayName:"\u0410\u0432\u0441\u0442\u0440\u0430\u043b\u0438\u0439\u0441\u043a\u0438\u0439 \u0434\u043e\u043b\u043b\u0430\u0440",JPY_displayName:"\u042f\u043f\u043e\u043d\u0441\u043a\u0430\u044f \u0438\u0435\u043d\u0430",CAD_symbol:"CA$",USD_displayName:"\u0414\u043e\u043b\u043b\u0430\u0440 \u0421\u0428\u0410",EUR_symbol:"\u20ac",CNY_symbol:"CN\u00a5",GBP_displayName:"\u0410\u043d\u0433\u043b\u0438\u0439\u0441\u043a\u0438\u0439 \u0444\u0443\u043d\u0442 \u0441\u0442\u0435\u0440\u043b\u0438\u043d\u0433\u043e\u0432",
GBP_symbol:"\u00a3",AUD_symbol:"A$",EUR_displayName:"\u0415\u0432\u0440\u043e"});
